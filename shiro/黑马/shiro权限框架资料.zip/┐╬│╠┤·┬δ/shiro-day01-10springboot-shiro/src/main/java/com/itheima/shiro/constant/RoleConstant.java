
package com.itheima.shiro.constant;



/**
 * @Description 角色常量类
 */

public class RoleConstant {
	
	public static final String PLATFORM="platform";

	public static final String TEACHERA="teachera";
	
	public static final String STUDENT="student";

	
	
}
