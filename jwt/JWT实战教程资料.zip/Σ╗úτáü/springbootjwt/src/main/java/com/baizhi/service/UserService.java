package com.baizhi.service;

import com.baizhi.entity.User;

public interface UserService {


    User login(User user);//登录接口
}