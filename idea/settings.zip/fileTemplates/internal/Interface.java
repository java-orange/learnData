#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* <p>Title: ${NAME}</p>
* <p>Description: ${DESC}</p>
* <p>Company: www.h-visions.com</p>
* <p>create date: ${DATE}</p>
*@author : xhjing
*@version :1.0.0
*/
public interface ${NAME} {
}

    