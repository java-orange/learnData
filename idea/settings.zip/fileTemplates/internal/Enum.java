#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
import com.hvisions.common.interfaces.IKeyValueObject;
/**
* <p>Title: ${NAME}</p>
* <p>Description: ${DESC}</p>
* <p>Company: www.h-visions.com</p>
* <p>create date: ${DATE}</p>
*@author : xhjing
*@version :1.0.0
*/
public enum ${NAME} implements IKeyValueObject {
    
    //参数用途
    ONE_TIME(1, ""),
    REPEAT(2, ""),
    ;

    ${NAME}(int code, String name) {
        this.code = code;
        this.name = name;
    }

    private int code;
    private String name;


    @Override
    public Integer getCode() {
        return code;
    }

    @Override
    public String getName() {
        return name;
    }

}
