package cn.itcast.server.service;

public interface HelloService {
    String sayHello(String name);
}
